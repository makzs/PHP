<?php 

    require_once "./Libraries/Rotas.php";
    $r = new Rotas();
    

?>